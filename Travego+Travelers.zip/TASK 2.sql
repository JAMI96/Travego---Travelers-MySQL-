SELECT * FROM PASSENGER;
SELECT * FROM PRICE;
-- How many females and males passengers traveld a min distance 600kms?
SELECT count(gender) , gender from passenger where distance <= 600 group by gender;
-- Find the min ticket price of a sleeper bus?
select min(price) from price where bus_type = 'sitting';
select * from price;
-- Select passenger names whose name sstart with character 's'
select * from passenger where passenger_name like 's%';
-- calculate the price charged for each passenger displaying name, boarding station, destination city,
-- bus_type, price in the output
SELECT passenger_name, Boarding_city, Destination_city, p.Bus_type, price
FROM passenger p
JOIN price pr ON p.Bus_type = pr.Bus_type AND p.Distance = pr.Distance;
-- What are passenger name and ticket price for those who travled 1000 kms on sitting in a bus
SELECT passenger_name, Price 
FROM PASSENGER 
JOIN PRICE 
ON PASSENGER.Bus_type = PRICE.BUS_TYPE 
AND PASSENGER.Distance = PRICE.Distance 
WHERE PASSENGER.Distance = 1000 
AND PASSENGER.Bus_type = 'SITTING';
-- what will be the sitting and sleeper bus charge for pallavi to travel from bengaluru to panaji
select distance from passenger where passenger_name = 'pallavi' and boarding_city = 'panaji';
select price from price where distance = 600 and bus_type = 'sleeper';
select price from price where distance = 600 and bus_type = 'sitting';
-- list the distances from the passenger table which are unique in a desc order
select distance from passenger group by distance order by distance desc;
-- display the passenger name and percentage of distance traveled by that passenger from the 
-- total distance traveled by all passengers without using user variables
SELECT passenger_name, (Distance/ (SELECT SUM(Distance) FROM PASSENGER)*100) as Percentage FROM PASSENGER;