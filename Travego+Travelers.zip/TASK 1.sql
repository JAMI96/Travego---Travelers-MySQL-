create schema Travego;

USE TRAVEGO;
create table passenger (
passenger_id int primary key,
passenger_name VARCHAR(20),
Category varchar(20),
Gender varchar(20),
Boarding_city varchar(20),
Destination_city varchar(20),
Distance int,
Bus_type varchar(20));

create table price(
id int primary key,
bus_type varchar(20),
distance int,
price int );

insert into passenger (passenger_id, passenger_name, category, Gender, Boarding_city, Destination_city, Distance, Bus_type)
values
(1,'Sejal', 'AC','F','BENGALURU','CHENNAI',350,'SLEEPER'),
(2,'ANMOL', 'NON-AC','M','MUMBAI','HYDERABAD',700,'SITTING'),
(3,'PALLAVI','AC','F','PANAJI','BENGALURU',600,'SLEEPER'),
(4,'KHUSBOO','AC','F','CHENNAI','MUMBAI',1500,'SLEEPER'),
(5,'UDIT','NON-AC','M','TRIVANDRUM','PANAJI',1000,'SLEEPER'),
(6,'ANKUR','AC','M','NAGPUR','HYDERABAD',500,'SITTING'),
(7,'HEMANT','NON-AC','M','PANAJI','MUMBAI',700,'SLEEPER'),
(8,'MANISH','NON-AC','M','HYDERABAD','BENGALURU',500,'SITTING'),
(9,'PIYUSH','AC','M','PUNE','NAGPUR',700,'SITTING');

INSERT INTO PRICE (ID, BUS_TYPE, DISTANCE, PRICE)
VALUES 
(1, 'SLEEPER',350,770),
(2,'SLEEPER',500,1100),
(3,'SLEEPER',600,1320),
(4,'SLEEPER',700,1540),
(5,'SLEEPER',1000,2240),
(6,'SLEEPER',1200,2640),
(7,'SLEEPER',1500,2700),
(8,'SITTING',500,620),
(9,'SITTING',600,744),
(10,'SITTING',700,868),
(11,'SITTING',1000,1240),
(12,'SITTING',1200,1488),
(13,'SITTING',1500,1860);
